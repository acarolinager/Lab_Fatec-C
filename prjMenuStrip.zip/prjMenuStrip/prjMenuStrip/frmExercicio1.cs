﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjMenuStrip
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacBranco_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int espBranco = 0;
            while (cont < rchTexto.Text.Length)
            {
                if (char.IsWhiteSpace(rchTexto.Text[cont]))
                {
                    espBranco++;
                }
                cont++;
            }
            MessageBox.Show("Numero de espaços em branco: " + espBranco);
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int letrasR = 0; 
            foreach(char c in rchTexto.Text)
            {
                if (char.ToUpper(c) == 'R')
                    letrasR++;
            }
            MessageBox.Show("O numero de letras R é: "+ letrasR);
        }

        private void btnRepetidas_Click(object sender, EventArgs e)
        {
            int letrasRep = 0;
            string aux = rchTexto.Text.Replace(" ", "");

            for(int i=1; i<aux.Length; i++)
            {
                if(aux[i] == aux[i-1])
                    letrasRep += 1;
            }
            MessageBox.Show("O numero de letras repetidas é: " + letrasRep);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rchTexto.Clear();
            rchTexto.Focus();
        }
    }
}
