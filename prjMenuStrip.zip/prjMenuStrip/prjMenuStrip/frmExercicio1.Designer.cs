﻿namespace prjMenuStrip
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTexto = new System.Windows.Forms.RichTextBox();
            this.btnEspacBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnRepetidas = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTexto
            // 
            this.rchTexto.Location = new System.Drawing.Point(23, 12);
            this.rchTexto.MaxLength = 100;
            this.rchTexto.Name = "rchTexto";
            this.rchTexto.Size = new System.Drawing.Size(252, 96);
            this.rchTexto.TabIndex = 0;
            this.rchTexto.Text = "";
            // 
            // btnEspacBranco
            // 
            this.btnEspacBranco.Location = new System.Drawing.Point(23, 114);
            this.btnEspacBranco.Name = "btnEspacBranco";
            this.btnEspacBranco.Size = new System.Drawing.Size(80, 47);
            this.btnEspacBranco.TabIndex = 1;
            this.btnEspacBranco.Text = "Espaços em branco";
            this.btnEspacBranco.UseVisualStyleBackColor = true;
            this.btnEspacBranco.Click += new System.EventHandler(this.btnEspacBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(109, 114);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(80, 47);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Letras \"R\"";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnRepetidas
            // 
            this.btnRepetidas.Location = new System.Drawing.Point(195, 114);
            this.btnRepetidas.Name = "btnRepetidas";
            this.btnRepetidas.Size = new System.Drawing.Size(80, 47);
            this.btnRepetidas.TabIndex = 3;
            this.btnRepetidas.Text = "Letras repetidas";
            this.btnRepetidas.UseVisualStyleBackColor = true;
            this.btnRepetidas.Click += new System.EventHandler(this.btnRepetidas_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(23, 167);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(252, 32);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 216);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnRepetidas);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspacBranco);
            this.Controls.Add(this.rchTexto);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTexto;
        private System.Windows.Forms.Button btnEspacBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnRepetidas;
        private System.Windows.Forms.Button btnLimpar;
    }
}