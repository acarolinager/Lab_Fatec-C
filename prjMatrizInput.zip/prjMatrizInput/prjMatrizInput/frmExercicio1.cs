﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace prjMatrizInput
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string aux;
            int[] vetor = new int[20]; 

            for(var x = 0; x < 20; x++)
            {
                aux = Interaction.InputBox("Digite um numero. " +
                    "Posição= " + (x+1) , "Entrada de dados");

                if(!int.TryParse(aux, out vetor[x]))
                {
                    MessageBox.Show("Valor inválido!");
                    x -= 1;
                }
            }
            Array.Reverse(vetor);
            aux = "";
            
            foreach(int i in vetor)
                aux = aux + "\n" + i;
            MessageBox.Show(aux);
        }
    }
}
