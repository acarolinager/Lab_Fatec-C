$("#esconder"). click ( function () {
    $("div"). slideUp ();
}
);
$("#mostrar"). click ( function () {
    $("div"). slideDown ();
}
);