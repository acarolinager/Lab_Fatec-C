﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrjMenu
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Conteudo copiado");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Conteudo colado");
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["formExe2"]; //Verifica se o formulario ja esta aberto. Caso esteja, ele vai fechar
            if (fc != null)
            {
                fc.Close();
            }

            frmExercicio2 formExe2 = new frmExercicio2(); //criando o objeto do formulario 2
            formExe2.MdiParent = this; //Define dentro de qual form o formExe2 vai abrir
            formExe2.WindowState = FormWindowState.Maximized; //Formulario vai abrir maximizado
            formExe2.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["formExe3"];
            if (fc != null)
            {
                fc.Close();
            }

            frmExercicio3 formExe3 = new frmExercicio3(); 
            formExe3.MdiParent = this; 
            formExe3.WindowState = FormWindowState.Maximized; 
            formExe3.Show();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["formExe4"];
            if (fc != null)
            {
                fc.Close();
            }

            frmExercicio4 formExe4 = new frmExercicio4(); 
            formExe4.MdiParent = this; 
            formExe4.WindowState = FormWindowState.Maximized; 
            formExe4.Show();
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["formExe5"];
            if (fc != null)
            {
                fc.Close();
            }

            frmExercicio5 formExe5 = new frmExercicio5();
            formExe5.MdiParent = this;
            formExe5.WindowState = FormWindowState.Maximized;
            formExe5.Show();
        }
    }
}
